## Datasets/Books Before Downloading
![Screenshot from 2023-01-06 19-15-51](https://user-images.githubusercontent.com/68748665/211037681-388bdf17-258b-4820-9c29-6f42f6fea39d.png)

## Datasets/Books After Downloading
![Screenshot from 2023-01-06 19-39-52](https://user-images.githubusercontent.com/68748665/211037695-fbb3be50-2f19-415b-8796-1bd4b8b037ce.png)
